document.addEventListener('DOMContentLoaded', () => {

    function initCustomJS() {
        // --- TEXT SPLITTING ---
        const words = document.querySelectorAll('.hero-brutal h1 .word');
        words.forEach(word => {
            // Avoid double splitting on Swup back navigations
            if (word.querySelector('.char')) return;

            const text = word.innerText;
            word.innerHTML = '';
            text.split('').forEach(char => {
                const span = document.createElement('span');
                span.classList.add('char');
                span.innerText = char;
                word.appendChild(span);
            });
        });

        // --- MAGNET & CURSOR ---
        const cursor = document.getElementById('cursor');
        const magneticElements = document.querySelectorAll('.magnetic, .btn, a'); // Globals for magnet effect

        let mouseX = 0, mouseY = 0;
        let cursorX = 0, cursorY = 0;

        window.addEventListener('mousemove', e => {
            mouseX = e.clientX;
            mouseY = e.clientY;
        });

        function lerp(start, end, factor) {
            return start + (end - start) * factor;
        }

        function animateCursor() {
            if (cursor) {
                cursorX = lerp(cursorX, mouseX, 0.15);
                cursorY = lerp(cursorY, mouseY, 0.15);
                cursor.style.transform = `translate(${cursorX}px, ${cursorY}px) translate(-50%, -50%)`;
            }
            requestAnimationFrame(animateCursor);
        }
        animateCursor();

        if (magneticElements.length > 0 && cursor) {
            magneticElements.forEach(el => {
                el.addEventListener('mousemove', (e) => {
                    const rect = el.getBoundingClientRect();
                    const centerX = rect.left + rect.width / 2;
                    const centerY = rect.top + rect.height / 2;
                    const dist = 0.5; // Magnetic strength

                    const moveX = (e.clientX - centerX) * dist;
                    const moveY = (e.clientY - centerY) * dist;

                    el.style.transform = `translate(${moveX}px, ${moveY}px)`;
                    cursor.classList.add('magnet');
                });

                el.addEventListener('mouseleave', () => {
                    el.style.transform = 'translate(0, 0)';
                    cursor.classList.remove('magnet');
                });
            });
        }

        // --- NAVBAR STATE & 3D TILT ---
        const nav = document.querySelector('.brutal-nav');
        let isScrolled = false;

        window.addEventListener('scroll', () => {
            if (nav) {
                if (window.scrollY > 50) {
                    if (!isScrolled) {
                        nav.classList.add('scrolled');
                        isScrolled = true;
                    }
                } else {
                    if (isScrolled) {
                        nav.classList.remove('scrolled');
                        nav.style.transform = '';
                        isScrolled = false;
                    }
                }
            }
        });

        document.addEventListener('mousemove', (e) => {
            if (!isScrolled || !nav) return;
            const cx = window.innerWidth / 2;
            const cy = 100; // Pivot near top

            // Subtle tilt
            const rx = (e.clientY - cy) * 0.02;
            const ry = (e.clientX - cx) * 0.02;

            const clamp = (num, min, max) => Math.min(Math.max(num, min), max);

            nav.style.transform = `translateX(-50%) perspective(1000px) rotateX(${-clamp(rx, -10, 10)}deg) rotateY(${clamp(ry, -10, 10)}deg)`;
        });

        // --- SCROLL VELOCITY SKEW ---
        const content = document.getElementById('scroll-content');
        if (content) {
            let skew = 0;
            let lastScrollTop = 0;

            function scrollLoop() {
                // Check if element still in DOM (Swup unmount protection)
                if (!document.body.contains(content)) return;

                const scrollTop = window.scrollY;
                const velocity = scrollTop - lastScrollTop;
                lastScrollTop = scrollTop;

                const maxSkew = 5.0;
                const speed = Math.min(Math.max(velocity * 0.1, -maxSkew), maxSkew);

                skew = lerp(skew, speed, 0.1);

                if (Math.abs(skew) > 0.01) {
                    content.style.transform = `skewY(${skew}deg)`;
                } else {
                    content.style.transform = `skewY(0deg)`;
                }
                requestAnimationFrame(scrollLoop);
            }
            scrollLoop();
        }

        // --- HACKER TEXT RE-INIT ---
        const alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        document.querySelectorAll('[data-text]').forEach(link => {
            // Prevent stacking listeners
            link.removeEventListener('mouseenter', link._hackerEnter);
            link.removeEventListener('mouseleave', link._hackerLeave);

            link._hackerEnter = event => {
                let iter = 0;
                const original = event.target.dataset.text;
                clearInterval(event.target.interval);

                event.target.interval = setInterval(() => {
                    event.target.innerText = original.split("")
                        .map((l, i) => {
                            if (i < iter) return original[i];
                            return alpha[Math.floor(Math.random() * 26)]
                        })
                        .join("");

                    if (iter >= original.length) clearInterval(event.target.interval);
                    iter += 1 / 3;
                }, 30);
            };

            link._hackerLeave = e => {
                clearInterval(e.target.interval);
                e.target.innerText = e.target.dataset.text;
            };

            link.addEventListener('mouseenter', link._hackerEnter);
            link.addEventListener('mouseleave', link._hackerLeave);
        });

        // Retain GSAP legacy checks if any remain
        if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
            gsap.registerPlugin(ScrollTrigger);
            // Kill old triggers mapped to previous DOM
            ScrollTrigger.getAll().forEach(t => t.kill());

            const revealElements = document.querySelectorAll('.gs-reveal');
            revealElements.forEach((elem) => {
                gsap.fromTo(elem,
                    { y: 50, opacity: 0 },
                    {
                        y: 0, opacity: 1, duration: 1, ease: "power3.out",
                        scrollTrigger: { trigger: elem, start: "top 85%", toggleActions: "play none none reverse" }
                    }
                );
            });
        }

    } // end initCustomJS

    // Execute once initially
    initCustomJS();



});
